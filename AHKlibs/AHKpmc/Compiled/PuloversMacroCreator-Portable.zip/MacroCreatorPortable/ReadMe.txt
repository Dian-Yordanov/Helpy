Pulover's Macro Creator v5.0.5 Portable Edition
===============================================

Thank you for downloading Pulover's Macro Creator.
Supported platforms: Windows 7, 8, 8.1, 10
NOT tested on: Windows XP, Vista

This file contains both x86 and x64 builds.
